from . import admin
from flask import jsonify, request
from .models.Admin import Admin
from app import bcrypt


@admin.route('/admin', methods=['GET'])
def get_all_admin():
    return jsonify(Admin.get_all())

@admin.cli.command('create_admin')
def create_admin():
    """Create admin: Allows you to enter a username and password to create an admin"""
    username = input('Enter username: ')
    password = input('Enter password: ')

    hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
    admin = Admin(username=username, password=hashed_password)
    admin.save()
    print('Admin created')